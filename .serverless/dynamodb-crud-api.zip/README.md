<!-- # DynamoDB CRUD API using API Gateway and AWS Lambda | Node.js w/ AWS-SDK V3

![visitors](https://visitor-badge.glitch.me/badge?page_id=jacksonyuan-yt.dynamodb-crud-api-gateway)

### YouTube Video Tutorial
* [Full Tutorial](https://youtu.be/hOcbHz4T0Eg) -->

readme.md file
