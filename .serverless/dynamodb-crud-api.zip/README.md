<!-- Name: Dhaval Rathod
This is project for creating DynamoDB with CRUD API and AWS Lambda using Node.js and AWS-SDK V3
github link:- https://github.com/Yahoogitzz/sls

Note: This is readme.md file -->
